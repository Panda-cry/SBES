﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Contracts;
using Manager;
using System.Security.Cryptography.X509Certificates;
using System.Threading;

namespace ServiceApp
{
	public class WCFService : IWCFContract
	{
        public void SendMessage(string message, byte[] sign)
        {
            //TO DO
            throw new NotImplementedException();
        }

        public void TestCommunication()
		{
			Console.WriteLine("Communication established.");
		}

		
    }
}
